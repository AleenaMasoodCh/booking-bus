
var tweet= prompt("compose your tweet: ");
var tweetCount=tweet.length;
alert("You have written "+ tweetCount + "characters you have" + (140-tweetCount) + "characters you have remaining");
